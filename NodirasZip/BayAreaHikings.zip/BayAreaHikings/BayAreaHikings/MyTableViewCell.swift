//
//  MyTableViewCell.swift
//  BayAreaHikings
//
//  Created by Nodira on 2/5/17.
//  Copyright © 2017 DeAnza. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    @IBOutlet var cellImage: UIImageView!
    
    @IBOutlet var cellItemName: UILabel!

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
