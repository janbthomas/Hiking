//
//  MyTableViewController.swift
//  BayAreaHikings
//
//  Created by Nodira on 2/5/17.
//  Copyright © 2017 DeAnza. All rights reserved.
//

import UIKit

class MyTableViewController: UITableViewController {
    
    var HikingsItems = ["San Francisco", "Napa Valley AVA", "San Jose", "Napa", "Big Basin Redwoods State Park", "Sonoma", "Oakland", "Berkeley", "Sausalito", "Half Moon Bay", "Santa Rosa", "PaloAlto", "Santa Clara", "Livermore", "Stanford", "Mountain View", "San Francisco Peninsula", "Fremont", "Tiburon", "Fairfield"]
    
    var HikingImages = [#imageLiteral(resourceName: "SanFrancisco"), #imageLiteral(resourceName: "NapaValleyAVA"), #imageLiteral(resourceName: "SanJose"), #imageLiteral(resourceName: "Napa"), #imageLiteral(resourceName: "BigBasin"), #imageLiteral(resourceName: "Sonoma"), #imageLiteral(resourceName: "Oakland"), #imageLiteral(resourceName: "Berkeley"),#imageLiteral(resourceName: "Sausalito"), #imageLiteral(resourceName: "HalfMoonBay"), #imageLiteral(resourceName: "SantaRosa"), #imageLiteral(resourceName: "PaloAlto"), #imageLiteral(resourceName: "SantaClara"), #imageLiteral(resourceName: "Livermore"), #imageLiteral(resourceName: "Stanford"), #imageLiteral(resourceName: "MountainView"), #imageLiteral(resourceName: "SanFranciscoPeninsula"), #imageLiteral(resourceName: "Fremont"), #imageLiteral(resourceName: "Tiburon"), #imageLiteral(resourceName: "Fairfield")]
    
    var HikingDescriptions = ["Hilly bayside city known for the Golden Gate Bridge, year round fog, cable cars & Victorian homes", "California region with hundreds of vineyards, plus hot springs & Napa Valley Wine Train tours", "Silicon Valley city with tech & art museums, plus historic landmarks like Winchester Mystery House", "Town in the Napa Valley with a downtown arts scene, Oxbow Public Market & Napa Wine Train", " Hiking trails & other outdoor activities", "Town in the Sonoma Valley winemaking region known for art galleries & a colonial-era plaza", "Parks, running, zoos, art, concerts, and ballet", "Northern California city with UC Berkeley, Greek Theatre, Telegraph Avenue & “Gourmet Ghetto”", "Burgers, walking, shopping, art, fog, and wine", "Beaches, surfing, hiking, fishing, and whales", "Parks, wine country, burgers, and cycling", " Parks, running, hiking, shopping, and wine", "Conference centre, parks, shopping, and art", "Wineries, parks, lakes, vineyards, and wine", "Shopping, Auguste Rodin, churches, and golf", "Parks, amphitheaters, bistros, and shopping", "Hiking, cycling, trail running, and gardens", "Parks lakes, hiking, running, and history", "Hiking, shopping, parks, walking, and cycling", " Parks, nightlife, mountain biking, and beer"]
    
    var HikingChecked = [false, false, false,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false]
    
    
    override var prefersStatusBarHidden: Bool {
        return true
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return HikingsItems.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "HikingCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! MyTableViewCell

        // Configure the cell...
        
        cell.cellImage?.image = HikingImages[indexPath.row]
        cell.cellItemName?.text = HikingsItems[indexPath.row]
  //      cell.cellItemDescription?.text = HikingDescriptions[indexPath.row]

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      //  let selectedItem = HikingsItems[indexPath.row]
      //  let selectedDescription = HikingDescriptions[indexPath.row]
     //   var hikingAlert: UIAlertController!
        
        //First reverce state of whether item was checked or not
        HikingChecked[indexPath.row] = !(HikingChecked[indexPath.row])
        
        //Now show or hide the checkmark on what the new state should be
        if HikingChecked[indexPath.row] {
            self.tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
            
     //       hikingAlert = UIAlertController(title: selectedItem, message: selectedDescription, preferredStyle: UIAlertControllerStyle.alert)

        }
        else {
            self.tableView.cellForRow(at: indexPath)?.accessoryType = .none
            
     //       hikingAlert = UIAlertController(title: selectedItem, message: "Reset", preferredStyle: UIAlertControllerStyle.alert)
        }
    
   //     hikingAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
   //     self.present(hikingAlert, animated: true, completion: nil)
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            HikingsItems.remove(at: indexPath.row)
            HikingImages.remove(at: indexPath.row)
            HikingDescriptions.remove(at: indexPath.row)
            HikingChecked.remove(at: indexPath.row)
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ShowItemDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let detailVC = segue.destination as! MyDetailViewController
                
                detailVC.LabelItemText = HikingsItems[indexPath.row]
                detailVC.LabelDescriptionText = HikingDescriptions[indexPath.row]
                detailVC.LabelImage = HikingImages[indexPath.row]
            }
        }

    }
    

}
